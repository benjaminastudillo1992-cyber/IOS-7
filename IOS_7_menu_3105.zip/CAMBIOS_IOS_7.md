# Cambios IOS !7

- Nombre visible de la aplicación y marca de inicio: IOS !7.
- La sección de dispositivo muestra el nombre comercial del iPhone cuando el identificador está en la tabla local; en modelos no reconocidos muestra el identificador detectado.
- La versión de iOS y el build continúan detectándose desde el sistema.

Nota: este paquete no agrega ni conecta aimbot, cheats, bypasses ni modificaciones para obtener ventajas en Free Fire. Los accesos existentes conservan las funciones legítimas de administración de archivos, proyectos y personalización.
