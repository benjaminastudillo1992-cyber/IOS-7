import SwiftUI
import UIKit

struct ContentView: View {
    @Environment(\.appLanguage) private var language
    @Environment(\.horizontalSizeClass) private var horizontalSizeClass
    @EnvironmentObject private var patchDraftCoordinator: PatchDraftCoordinator
    @State private var tabNavigation: AppTabNavigationState
    @AppStorage(FeatureVisibility.cleanerStorageKey) private var cleanerEnabled = true
    @AppStorage(FeatureVisibility.wallpapersStorageKey) private var wallpapersEnabled = true

    init() {
#if targetEnvironment(simulator)
        let arguments = ProcessInfo.processInfo.arguments
        let initialTab: Int
        if arguments.contains("--simulate-files-tab") {
            initialTab = 1
        } else if arguments.contains("--simulate-patch-tab") {
            initialTab = 2
        } else if arguments.contains("--simulate-cleaner-tab") {
            initialTab = 3
        } else if arguments.contains("--simulate-wallpaper-tab") {
            initialTab = 4
        } else {
            initialTab = AppSection.patches.rawValue
        }
        _tabNavigation = State(initialValue: AppTabNavigationState(selectedTab: initialTab))
#else
        _tabNavigation = State(initialValue: AppTabNavigationState())
#endif
    }

    var body: some View {
        IOS7GameLauncherView()
            .background(Color.black.ignoresSafeArea())
            .statusBarHidden(true)
            .tint(.cyan)
        .onChange(of: patchDraftCoordinator.request?.id) { requestID in
            if requestID != nil { tabNavigation.select(AppSection.patches.rawValue) }
        }
        .onChange(of: patchDraftCoordinator.importRequest?.id) { requestID in
            if requestID != nil { tabNavigation.select(AppSection.patches.rawValue) }
        }
        .onChange(of: cleanerEnabled) { _ in
            tabNavigation.reconcileSelection(with: featureVisibility)
        }
        .onChange(of: wallpapersEnabled) { _ in
            tabNavigation.reconcileSelection(with: featureVisibility)
        }
        .onAppear {
            tabNavigation.reconcileSelection(with: featureVisibility)
        }
    }

    private var compactLayout: some View {
        TabView(selection: tabSelection) {
            ForEach(featureVisibility.visibleSections) { section in
                sectionContent(section)
                    .tabItem {
                        CompactTabLabel(
                            title: language.text(section.titleKey),
                            systemImage: section.systemImage
                        )
                    }
                    .tag(section.rawValue)
            }
        }
    }

    private var regularLayout: some View {
        NavigationSplitView {
            List {
                ForEach(featureVisibility.visibleSections) { section in
                    Button {
                        withAnimation(.easeInOut(duration: 0.18)) {
                            tabNavigation.select(section.rawValue)
                        }
                    } label: {
                        Label(language.text(section.titleKey), systemImage: section.systemImage)
                            .fontWeight(section.rawValue == tabNavigation.selectedTab ? .semibold : .regular)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .contentShape(Rectangle())
                    }
                    .buttonStyle(.plain)
                    .listRowBackground(
                        section.rawValue == tabNavigation.selectedTab
                            ? AppTheme.accent.opacity(0.14)
                            : Color.clear
                    )
                    .accessibilityAddTraits(
                        section.rawValue == tabNavigation.selectedTab ? .isSelected : []
                    )
                }
            }
            .navigationTitle("IOS !7")
            .navigationSplitViewColumnWidth(min: 210, ideal: 240, max: 300)
        } detail: {
            sectionContent(selectedVisibleSection)
                .id(selectedVisibleSection.rawValue)
        }
        .navigationSplitViewStyle(.balanced)
    }

    @ViewBuilder
    private func sectionContent(_ section: AppSection) -> some View {
        switch section {
        case .home:
            DashboardView(
                cleanerEnabled: $cleanerEnabled,
                wallpapersEnabled: $wallpapersEnabled,
                wallpapersSupported: wallpapersSupported
            )
        case .files:
            AppDataBrowserView(
                tabSession: filesTabSession
            )
        case .patches:
            PatchProjectsView(ghostTheme: true)
        case .cleaner:
            CleanerView()
        case .wallpapers:
            WallpaperLabView()
        }
    }

    private var tabSelection: Binding<Int> {
        Binding(
            get: { tabNavigation.selectedTab },
            set: { tabNavigation.select($0) }
        )
    }

    private var filesTabSession: Binding<FilesTabSession> {
        Binding(
            get: { tabNavigation.filesTabs },
            set: { tabNavigation.setFilesTabs($0) }
        )
    }

    private var featureVisibility: FeatureVisibility {
        FeatureVisibility(
            cleanerEnabled: cleanerEnabled,
            wallpapersEnabled: wallpapersEnabled,
            wallpapersSupported: wallpapersSupported
        )
    }

    private var wallpapersSupported: Bool {
        WallpaperFeatureSupportPolicy.isSupported(major: AppInfo.versionTuple.major)
    }

    private var selectedVisibleSection: AppSection {
        guard let section = AppSection(rawValue: tabNavigation.selectedTab),
              featureVisibility.isVisible(section) else {
            return .patches
        }
        return section
    }
}

private struct CompactTabLabel: View {
    let title: String
    let systemImage: String

    @ViewBuilder
    var body: some View {
        if let image = UIImage(
            systemName: systemImage,
            withConfiguration: UIImage.SymbolConfiguration(pointSize: 17, weight: .medium)
        )?.withRenderingMode(.alwaysTemplate) {
            Image(uiImage: image)
        } else {
            Image(systemName: systemImage)
                .font(.system(size: 17, weight: .medium))
        }
        Text(title)
    }
}

private extension AppSection {
    var titleKey: String {
        switch self {
        case .home: return "tab.home"
        case .files: return "tab.files"
        case .patches: return "tab.patches"
        case .cleaner: return "tab.cleaner"
        case .wallpapers: return "tab.wallpapers"
        }
    }

    var systemImage: String {
        switch self {
        case .home: return "house.fill"
        case .files: return "folder.fill"
        case .patches: return "shippingbox.fill"
        case .cleaner: return "sparkles"
        case .wallpapers: return "photo.on.rectangle.angled"
        }
    }
}

private struct DashboardView: View {
    @Environment(\.appLanguage) private var language
    @EnvironmentObject private var appState: AppState
    @State private var showSettings = false
    @State private var showLogs = false
    @Binding var cleanerEnabled: Bool
    @Binding var wallpapersEnabled: Bool
    let wallpapersSupported: Bool

    var body: some View {
        NavigationStack {
            List {
                deviceSection
                featuresSection
            }
            .navigationBarTitleDisplayMode(.inline)
            .tint(AppTheme.accent)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button { showLogs = true } label: {
                        Image(systemName: "apple.terminal")
                    }
                    .accessibilityLabel(language.text("accessibility.open_logs"))
                }
                ToolbarItem(placement: .navigationBarTrailing) {
                    Link(destination: URL(string: "https://t.me/+6L89Qcso3w9kN2Yx")!) {
                        Image(systemName: "paperplane.fill")
                            .foregroundStyle(.cyan)
                    }
                    .accessibilityLabel("Abrir grupo de Telegram")
                }
            }
            .sheet(isPresented: $showSettings) { SettingsView() }
            .sheet(isPresented: $showLogs) { LogView() }
        }
    }

    private var featuresSection: some View {
        Section {
            Toggle(isOn: $cleanerEnabled) {
                Label(language.text("tab.cleaner"), systemImage: "sparkles")
            }
            if wallpapersSupported {
                Toggle(isOn: $wallpapersEnabled) {
                    Label(language.text("tab.wallpapers"), systemImage: "photo.on.rectangle.angled")
                }
            }
        } header: {
            Text(language.text("dashboard.features"))
        } footer: {
            Text(language.text("dashboard.features_footer"))
        }
    }

    private var deviceSection: some View {
        Section {
            LabeledContent(language.text("dashboard.hardware_model")) {
                Text(AppInfo.hardwareDisplayName)
                    .font(.body.monospaced())
            }
            LabeledContent(language.text("settings.ios_version")) {
                Text("\(AppInfo.osVersion) (\(AppInfo.osBuild))")
                    .font(.body.monospaced())
            }
            HStack {
                Text(language.text("settings.compatibility"))
                Spacer()
                Text(language.text(appState.isSupported ? "settings.supported" : "settings.unsupported"))
                .foregroundStyle(appState.isSupported ? Color.green : Color.red)
            }

            if appState.kernelExploitApplicable && AppInfo.versionTuple.major < 26 {
                HStack {
                    Text(language.text("dashboard.kernel_status"))
                    Spacer()
                    if appState.kernelExploitRunning {
                        HStack(spacing: 6) {
                            ProgressView().controlSize(.small)
                            Text(language.text("dashboard.kernel_running"))
                                .font(.subheadline)
                                .foregroundStyle(.secondary)
                        }
                    } else {
                        Text(language.text(appState.exploitStatus.isSuccess ? "dashboard.kernel_active" : "dashboard.kernel_inactive"))
                        .foregroundStyle(appState.exploitStatus.isSuccess ? Color.green : Color.secondary)
                    }
                }
            }
        } header: {
            Text(language.text("common.device"))
        } footer: {
            Text(language.text("settings.supported_range_summary"))
        }
    }
}


// Pantalla de navegación y demostración visual. Los interruptores son solo UI:
// no modifican Free Fire ni aplican parches o ventajas en el juego.
private struct IOS7GameLauncherView: View {
    @State private var showFunctions = false
    @State private var selectedGame = "FF MAX"

    var body: some View {
        ZStack {
            LinearGradient(
                colors: [Color(red: 0.01, green: 0.04, blue: 0.10),
                         Color(red: 0.00, green: 0.10, blue: 0.22),
                         .black],
                startPoint: .topLeading, endPoint: .bottomTrailing
            ).ignoresSafeArea()

            if showFunctions {
                IOS7FunctionsPreview(selectedGame: selectedGame) {
                    withAnimation(.easeInOut(duration: 0.25)) { showFunctions = false }
                }
            } else {
                VStack(spacing: 22) {
                    Spacer()
                    Image(systemName: "bolt.shield.fill")
                        .font(.system(size: 64, weight: .bold))
                        .foregroundStyle(.cyan)
                    Text("IOS !7")
                        .font(.system(size: 38, weight: .black, design: .rounded))
                        .foregroundStyle(.white)
                    Text("Selecciona tu versión de Free Fire")
                        .font(.system(size: 16, weight: .medium))
                        .foregroundStyle(.white.opacity(0.68))
                    gameButton("FF MAX", subtitle: "Open Free Fire Max", icon: "gamecontroller.fill")
                    gameButton("FF NORMAL", subtitle: "Open Free Fire", icon: "gamecontroller")
                    Spacer()
                    Text("MENÚ DE DEMOSTRACIÓN")
                        .font(.system(size: 11, weight: .semibold, design: .rounded))
                        .tracking(2)
                        .foregroundStyle(.white.opacity(0.35))
                        .padding(.bottom, 28)
                }
                .padding(.horizontal, 24)
            }
        }
    }

    private func gameButton(_ title: String, subtitle: String, icon: String) -> some View {
        Button {
            selectedGame = title
            withAnimation(.easeInOut(duration: 0.25)) { showFunctions = true }
        } label: {
            HStack(spacing: 16) {
                Image(systemName: icon)
                    .font(.system(size: 27, weight: .bold))
                    .foregroundStyle(.cyan)
                    .frame(width: 52, height: 52)
                    .background(.cyan.opacity(0.13), in: RoundedRectangle(cornerRadius: 15))
                VStack(alignment: .leading, spacing: 5) {
                    Text(title).font(.system(size: 22, weight: .heavy, design: .rounded))
                    Text(subtitle).font(.system(size: 14)).foregroundStyle(.white.opacity(0.62))
                }
                .foregroundStyle(.white)
                Spacer()
                Image(systemName: "chevron.right")
                    .font(.system(size: 20, weight: .bold))
                    .foregroundStyle(.white)
            }
            .padding(18)
            .background(.black.opacity(0.58), in: RoundedRectangle(cornerRadius: 24))
            .overlay(RoundedRectangle(cornerRadius: 24).stroke(.white.opacity(0.28), lineWidth: 1.5))
        }
        .buttonStyle(.plain)
    }
}

private struct IOS7FunctionsPreview: View {
    let selectedGame: String
    let onBack: () -> Void
    @State private var tab = 0
    @State private var head = false
    @State private var neck = false
    @State private var chest = false

    var body: some View {
        VStack(spacing: 0) {
            HStack(spacing: 12) {
                Image(systemName: "gearshape.fill").font(.system(size: 29, weight: .bold))
                VStack(alignment: .leading, spacing: 3) {
                    Text("FUNÇÕES DO 3105")
                        .font(.system(size: 25, weight: .black, design: .rounded))
                    Text("Recursos e pacotes disponíveis")
                        .font(.system(size: 14)).foregroundStyle(.white.opacity(0.72))
                }
                Spacer(minLength: 0)
            }
            .foregroundStyle(.white)
            .padding(.top, 16)
            .padding(.bottom, 28)

            HStack(spacing: 12) {
                tabButton("AIMBOT", index: 0)
                tabButton("TEXTURAS", index: 1)
            }
            .padding(.bottom, 24)

            if tab == 0 {
                VStack(spacing: 14) {
                    demoToggle("AVATAR CABEZA", detail: "Pré-visualização · recurso demonstrativo", value: $head)
                    demoToggle("AVATAR CUELLO", detail: "Pré-visualização · recurso demonstrativo", value: $neck)
                    demoToggle("AVATAR PECHO", detail: "Pré-visualização · recurso demonstrativo", value: $chest)
                }
            } else {
                VStack(spacing: 14) {
                    demoToggle("TEXTURA AZUL", detail: "Pré-visualização visual", value: $head)
                    demoToggle("TEXTURA OSCURA", detail: "Pré-visualização visual", value: $neck)
                    demoToggle("TEXTURA CLÁSICA", detail: "Pré-visualização visual", value: $chest)
                }
            }

            Spacer(minLength: 20)
            HStack(spacing: 12) {
                Button(action: onBack) {
                    Label("Volver", systemImage: "chevron.left")
                        .frame(maxWidth: .infinity).frame(height: 58)
                }
                .buttonStyle(IOS7FooterButtonStyle())
                Button(action: {}) {
                    Label("Abrir Free Fire", systemImage: "gamecontroller.fill")
                        .frame(maxWidth: .infinity).frame(height: 58)
                }
                .buttonStyle(IOS7FooterButtonStyle())
            }
            .padding(.bottom, 22)
        }
        .padding(.horizontal, 22)
        .background(
            LinearGradient(colors: [Color(red: 0.01, green: 0.08, blue: 0.17), .black],
                           startPoint: .top, endPoint: .bottom).ignoresSafeArea()
        )
    }

    private func tabButton(_ title: String, index: Int) -> some View {
        Button { withAnimation(.easeInOut(duration: 0.18)) { tab = index } } label: {
            Text(title)
                .font(.system(size: 16, weight: .heavy, design: .rounded))
                .tracking(1.2)
                .foregroundStyle(tab == index ? .white : .cyan)
                .frame(maxWidth: .infinity).frame(height: 62)
                .background(tab == index ? Color.cyan.opacity(0.78) : .black.opacity(0.35),
                            in: Capsule())
                .overlay(Capsule().stroke(.cyan.opacity(0.65), lineWidth: 1.2))
        }
        .buttonStyle(.plain)
    }

    private func demoToggle(_ title: String, detail: String, value: Binding<Bool>) -> some View {
        HStack(spacing: 15) {
            Image(systemName: "scope")
                .font(.system(size: 30, weight: .regular))
                .foregroundStyle(.white)
                .frame(width: 52)
            VStack(alignment: .leading, spacing: 5) {
                Text(title).font(.system(size: 17, weight: .bold, design: .rounded))
                    .foregroundStyle(.white)
                Text(detail).font(.system(size: 12))
                    .foregroundStyle(.white.opacity(0.58)).lineLimit(1)
            }
            Spacer(minLength: 2)
            Toggle(title, isOn: value).labelsHidden().tint(.cyan)
        }
        .padding(.horizontal, 16).padding(.vertical, 19)
        .background(Color(white: 0.10).opacity(0.96), in: RoundedRectangle(cornerRadius: 25))
        .overlay(RoundedRectangle(cornerRadius: 25).stroke(.white.opacity(0.13), lineWidth: 1))
    }
}

private struct IOS7FooterButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.system(size: 15, weight: .bold, design: .rounded))
            .foregroundStyle(.white)
            .background(Color(white: 0.12).opacity(configuration.isPressed ? 0.7 : 1),
                        in: RoundedRectangle(cornerRadius: 20))
            .overlay(RoundedRectangle(cornerRadius: 20).stroke(.white.opacity(0.24), lineWidth: 1))
    }
}
